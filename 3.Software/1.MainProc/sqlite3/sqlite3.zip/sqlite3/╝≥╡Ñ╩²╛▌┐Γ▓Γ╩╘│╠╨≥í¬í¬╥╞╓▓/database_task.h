#ifndef _DATABASE_TASK_H_
#define _DATABASE_TASK_H_ 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
//#include "datatype.h"
#include "sqlite3.h"
#include <time.h>

void *database_task( );

#endif
